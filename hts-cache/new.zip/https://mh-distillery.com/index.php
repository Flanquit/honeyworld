<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en" prefix="og: http://ogp.me/ns#"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang="en" prefix="og: http://ogp.me/ns#"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang="en" prefix="og: http://ogp.me/ns#"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en" prefix="og: http://ogp.me/ns#"> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <title>Milk &amp; Honey – Israel’s first whisky distillery |M&amp;H Whisky Distillery</title>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"/>
    <meta name="theme-color" content="#fdb813">
    <link rel="icon" type="file/ico" href="https://mh-distillery.com/wp-content/themes/anova/assets/images/favicon.ico">

    <link rel="alternate" hreflang="he" href="https://mh-distillery.com/he/" />
<link rel="alternate" hreflang="en" href="https://mh-distillery.com" />

<!-- This site is optimized with the Yoast SEO plugin v7.8 - https://yoast.com/wordpress/plugins/seo/ -->
<meta name="description" content="We are Milk &amp; Honey, M&amp;H Whisky Distillery, Israel’s first whisky distillery. We invite you to read more about us and, of course, visit us at the distillery in the heart of Tel Aviv."/>
<link rel="canonical" href="https://mh-distillery.com/" />
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="website" />
<meta property="og:title" content="Milk &amp; Honey – Israel’s first whisky distillery |M&amp;H Whisky Distillery" />
<meta property="og:description" content="We are Milk &amp; Honey, M&amp;H Whisky Distillery, Israel’s first whisky distillery. We invite you to read more about us and, of course, visit us at the distillery in the heart of Tel Aviv." />
<meta property="og:url" content="https://mh-distillery.com/" />
<meta property="og:site_name" content="M&amp;H Whisky Distillery." />
<meta name="twitter:card" content="summary" />
<meta name="twitter:description" content="We are Milk &amp; Honey, M&amp;H Whisky Distillery, Israel’s first whisky distillery. We invite you to read more about us and, of course, visit us at the distillery in the heart of Tel Aviv." />
<meta name="twitter:title" content="Milk &amp; Honey – Israel’s first whisky distillery |M&amp;H Whisky Distillery" />
<meta name="twitter:site" content="@milkhoneywhisky" />
<meta name="twitter:image" content="https://mh-distillery.com/wp-content/uploads/2018/01/logo.png" />
<meta name="twitter:creator" content="@milkhoneywhisky" />
<script type='application/ld+json'>{"@context":"https:\/\/schema.org","@type":"WebSite","@id":"#website","url":"https:\/\/mh-distillery.com\/","name":"M&amp;H Whisky Distillery.","potentialAction":{"@type":"SearchAction","target":"https:\/\/mh-distillery.com\/?s={search_term_string}","query-input":"required name=search_term_string"}}</script>
<!-- / Yoast SEO plugin. -->

<link rel='dns-prefetch' href='//ajax.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/svg\/","svgExt":".svg","source":{"concatemoji":"\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.11"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel="stylesheet" href="/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.0.3">
<link rel="stylesheet" href="/wp-content/plugins/rac/assets/sweetalert2/sweetalert2.min.css?ver=4.9.11">
<link rel="stylesheet" href="/wp-content/plugins/rac/assets/sweetalert2/sweetalert2.css?ver=4.9.11">
<link rel="stylesheet" href="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/themes/smoothness/jquery-ui.min.css?ver=4.9.11">
<link rel="stylesheet" href="/wp-content/plugins/woocommerce-bookings/assets/css/frontend.css?ver=1.11.2">
<link rel="stylesheet" href="/wp-content/plugins/woocommerce-follow-up-emails/templates/followups.css?ver=4.8.10">
<link rel="stylesheet" href="/wp-content/plugins/woocommerce-menu-bar-cart/css/wpmenucart-icons.css?ver=4.9.11">
<link rel="stylesheet" href="/wp-content/plugins/woocommerce-menu-bar-cart/css/wpmenucart-fontawesome.css?ver=4.9.11">
<link rel="stylesheet" href="/wp-content/plugins/woocommerce-menu-bar-cart/css/wpmenucart-main.css?ver=4.9.11">
<link rel="stylesheet" href="/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css?ver=3.4.3">
<link rel="stylesheet" href="/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css?ver=3.4.3" media="only screen and (max-width: 768px)">
<link rel="stylesheet" href="/wp-content/plugins/woocommerce/assets/css/woocommerce.css?ver=3.4.3">
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel="stylesheet" href="//mh-distillery.com/wp-content/plugins/sitepress-multilingual-cms/templates/language-switchers/legacy-list-horizontal/style.css?ver=1">
<style id='wpml-legacy-horizontal-list-0-inline-css' type='text/css'>
.wpml-ls-statics-shortcode_actions{background-color:#ffffff;}.wpml-ls-statics-shortcode_actions, .wpml-ls-statics-shortcode_actions .wpml-ls-sub-menu, .wpml-ls-statics-shortcode_actions a {border-color:#cdcdcd;}.wpml-ls-statics-shortcode_actions a {color:#444444;background-color:#ffffff;}.wpml-ls-statics-shortcode_actions a:hover,.wpml-ls-statics-shortcode_actions a:focus {color:#000000;background-color:#eeeeee;}.wpml-ls-statics-shortcode_actions .wpml-ls-current-language>a {color:#444444;background-color:#ffffff;}.wpml-ls-statics-shortcode_actions .wpml-ls-current-language:hover>a, .wpml-ls-statics-shortcode_actions .wpml-ls-current-language>a:focus {color:#000000;background-color:#eeeeee;}
</style>
<link rel="stylesheet" href="/wp-content/themes/roots/assets/css/main.min.css?ver=9a2dd99b82ca338b034e8730b94139d2">
<script type='text/javascript' src='//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script>
<script>window.jQuery || document.write('<script src="https://mh-distillery.com/wp-content/themes/roots/assets/js/vendor/jquery-1.10.2.min.js"><\/script>')</script>
<script type='text/javascript' src='/wp-content/plugins/woocommerce-multilingual/res/js/front-scripts.min.js?ver=4.3.3'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var actions = {"is_lang_switched":"0","force_reset":"0"};
/* ]]> */
</script>
<script type='text/javascript' src='/wp-content/plugins/woocommerce-multilingual/res/js/cart_widget.min.js?ver=4.3.3'></script>
<script type='text/javascript' src='/wp-content/plugins/sitepress-multilingual-cms/res/js/jquery.cookie.js?ver=4.0.4'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wpml_cookies = {"_icl_current_language":{"value":"en","expires":1,"path":"\/"}};
var wpml_cookies = {"_icl_current_language":{"value":"en","expires":1,"path":"\/"}};
/* ]]> */
</script>
<script type='text/javascript' src='/wp-content/plugins/sitepress-multilingual-cms/res/js/cookies/language-cookie.js?ver=4.9.11'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var rac_guest_params = {"console_error":"Not a valid e-mail address","current_lang_code":"en","ajax_url":"https:\/\/mh-distillery.com\/wp-admin\/admin-ajax.php","guest_entry":"f0ee1af7c7","is_checkout":"","is_shop":"","ajax_add_to_cart":"yes","enable_popup":"no","form_label":"Please enter your Details","first_name":"","email_address_not_valid":"Please Enter your Valid Email Address","enter_email_address":"Please Enter your Email Address","enter_first_name":"Please Enter your First Name","enter_phone_no":"Please Enter your Contact Number","enter_valid_phone_no":"Please Enter valid Contact Number","enter_last_name":"Please Enter your Last Name","cancel_label":"Cancel","add_to_cart_label":"Add to cart","force_guest":"no","show_guest_name":"","show_guest_contactno":"","force_guest_name":"","force_guest_contactno":"","popup_already_displayed":"no","is_cookie_already_set":"","fp_rac_popup_email":"","fp_rac_first_name":"","fp_rac_last_name":"","fp_rac_phone_no":"","fp_rac_disp_notice_check":"","fp_rac_disp_notice":"Your email will be used for sending Abandoned Cart emails","popup_disp_method":"1","popup_cookie_delay_time":"no","rac_popup_delay_nonce":"d5b6bf20c0"};
var custom_css_btn_color = {"popupcolor":"FFFFFF","confirmbtncolor":"008000","cancelbtncolor":"CC2900","email_placeholder":"Enter your Email Address","fname_placeholder":"Enter your First Name","lname_placeholder":"Enter your Last Name","phone_placeholder":"Enter Your Contact Number"};
/* ]]> */
</script>
<script type='text/javascript' src='/wp-content/plugins/rac/assets/js/fp-rac-guest-checkout.js?ver=21.3'></script>
<script type='text/javascript' src='/wp-content/plugins/rac/assets/sweetalert2/sweetalert2.min.js?ver=4.9.11'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var FUE = {"ajaxurl":"https:\/\/mh-distillery.com\/wp-admin\/admin-ajax.php","ajax_loader":"https:\/\/mh-distillery.com\/wp-content\/plugins\/woocommerce-follow-up-emails\/templates\/images\/ajax-loader.gif"};
/* ]]> */
</script>
<script type='text/javascript' src='/wp-content/plugins/woocommerce-follow-up-emails/templates/js/fue-account-subscriptions.js?ver=4.8.10'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wpmenucart_ajax_assist = {"shop_plugin":"woocommerce","always_display":""};
/* ]]> */
</script>
<script type='text/javascript' src='/wp-content/plugins/woocommerce-menu-bar-cart/javascript/wpmenucart-ajax-assist.js?ver=4.9.11'></script>
<script type='text/javascript' src='/wp-content/themes/roots/assets/js/vendor/modernizr-2.6.2.min.js'></script>
<link rel='https://api.w.org/' href='https://mh-distillery.com/wp-json/' />
<link rel="alternate" type="application/json+oembed" href="https://mh-distillery.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fmh-distillery.com%2F" />
<link rel="alternate" type="text/xml+oembed" href="https://mh-distillery.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fmh-distillery.com%2F&#038;format=xml" />
<meta name="generator" content="WPML ver:4.0.4 stt:1,20;" />
        <style type="text/css">
        #fp_rac_guest_email_in_cookie{

}
#fp_rac_guest_fname_in_cookie{

}
#fp_rac_guest_lname_in_cookie{

}
#fp_rac_guest_phoneno_in_cookie{

}        </style>
        	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<link rel="icon" href="https://mh-distillery.com/wp-content/uploads/2018/01/cropped-logo-32x32.png" sizes="32x32" />
<link rel="icon" href="https://mh-distillery.com/wp-content/uploads/2018/01/cropped-logo-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="https://mh-distillery.com/wp-content/uploads/2018/01/cropped-logo-180x180.png" />
<meta name="msapplication-TileImage" content="https://mh-distillery.com/wp-content/uploads/2018/01/cropped-logo-270x270.png" />
		<style type="text/css" id="wp-custom-css">
			@media(max-width:767px){
#select_tour{
	font-size: 13px;
}
}

.section2 p {
    font-family: opensans;
    font-size: 15px;
    line-height: 15px;
    color: #000;
}
		</style>
	<!-- WooCommerce Google Analytics Integration -->
		<script type='text/javascript'>
			var gaProperty = 'UA-78804228-1';
			var disableStr = 'ga-disable-' + gaProperty;
			if ( document.cookie.indexOf( disableStr + '=true' ) > -1 ) {
				window[disableStr] = true;
			}
			function gaOptout() {
				document.cookie = disableStr + '=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/';
				window[disableStr] = true;
			}
		</script>
		<script type='text/javascript'>(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		})(window,document,'script','//www.google-analytics.com/analytics.js','ga');ga( 'create', 'UA-78804228-1', 'mh-distillery.com' );ga( 'set', 'anonymizeIp', true );
		ga( 'set', 'dimension1', 'no' );
ga( 'require', 'ec' );</script>
		<!-- /WooCommerce Google Analytics Integration -->    
    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
            new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
            j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
            'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-K278ZN7');</script>
    <!-- End Google Tag Manager -->

    <link rel="alternate" type="application/rss+xml" title="M&amp;H Whisky Distillery. Feed" href="https://mh-distillery.com/feed/">
    <link rel="stylesheet" href="https://mh-distillery.com/wp-content/themes/anova/assets/css/slick-theme.css" type="text/css" />
    <link rel="stylesheet" href="https://mh-distillery.com/wp-content/themes/anova/assets/css/slick.css" type="text/css" />
    <link rel="stylesheet" href="/wp-content/themes/anova/style.css?v=1.0.1" type="text/css" />
    
    <script type="text/javascript" src="https://mh-distillery.com/wp-content/themes/anova/assets/js/buttons.js"></script>
    <script type="text/javascript">stLight.options({publisher: "3b97e1d5-1ec4-4a58-aaca-226d1b6990ee", doNotHash: false, doNotCopy: false, hashAddressBar: false});</script>

    <script async defer src="//assets.pinterest.com/js/pinit.js"></script>

    
<!--        -->
    <script>
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

        ga('create', 'UA-78804228-1', 'auto');
        ga('send', 'pageview');

    </script>
    <script>
        $(function() {
            $( "#datepicker" ).datepicker();
        });

        var getLangCode = 'en';
    </script>
    <style type="text/css">
        .wc-bookings-date-picker .ui-datepicker td.fully_booked a:hover::before,
        .wc-bookings-date-picker .ui-datepicker td.fully_booked span:hover::before,
        .wc-bookings-date-picker .ui-datepicker td.not_bookable span:hover::before,
        .wc-bookings-date-picker .ui-datepicker td.not-bookable span:hover::before
        {
            content: 'Not enough tickets left';
        }
    </style>

<script type="text/javascript">
    window._tfa = window._tfa || [];
    _tfa.push({ notify: 'mark',type: 'MnH_site_rem' });
</script>
<script src="//cdn.taboola.com/libtrc/flow-mh-sc/tfa.js"></script>

</head>
<body class="home page woocommerce-no-js">
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-K278ZN7"
                  height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

    


<!--        -->
<div id="fb-root"></div>
<script>(function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.6";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>


<!--[if lt IE 8]><div class="alert alert-warning">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</div><![endif]-->
    <div class="open-js"></div>
    <div class="open-mh">
                    <img class="background-img" src="https://mh-distillery.com/wp-content/themes/anova/assets/images/background.jpg"/>
                <div class="yesno">
            <img src="https://mh-distillery.com/wp-content/uploads/2016/04/icon-login.png"/>
            <h3>Are you of legal drinking age</h3>
            <h5>in your country?</h5>
            <h5 id="yes" class="answers" onclick="">YES</h5>
            <h5 id="no" class="answers" onclick="">NO</h5>
        </div>
        <div class="select-no">
            <h3>Sorry</h3>
            <h4>You must be of legal drinking age to enter this site</h4>
        </div>
    </div>
<header class="clearfix" role="banner">
    <div class="wrapper">
        <div class="navbar-header-mobail">
            <a class="logo" href="https://mh-distillery.com" title="karpri logo"><img src="https://mh-distillery.com/wp-content/themes/anova/assets/images/logo-web.jpg"/></a>
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
<!--            <nav class="collapse navbar-collapse" role="navigation">-->
<!--                --><!--            </nav>-->
        </div>
        <div class="clearfix">
        <div class="menu">
            <div class="clearfix"></div>
            <div class="no-mobail">
                            <img class="yellow-strips" src="https://mh-distillery.com/wp-content/themes/anova/assets/images/yellow-strips.png"/>
                        </div>
            <div class="max-container">
                <div class="no-mobail">
                                    <img class="yellow-strips-mobail" src="https://mh-distillery.com/wp-content/themes/anova/assets/images/yellow-strips.png"/>
                                <div class="logo">
                   <a href="https://mh-distillery.com" title="karpri logo"><img src="https://mh-distillery.com/wp-content/themes/anova/assets/images/logo.png"/></a>
                </div>
                </div>
                <nav class="collapse navbar-collapse nav-d" role="navigation">
                    <ul id="menu-menu-main" class="nav navbar-nav"><li class="dropdown menu-our-products"><a class="dropdown-toggle" data-toggle="dropdown" data-target="#" href="https://mh-distillery.com/our-spirits/">Our Products <b class="caret"></b></a>
<ul class="dropdown-menu">
	<li class="menu-our-spirits"><a href="https://mh-distillery.com/our-spirits/">Our Spirits</a></li>
	<li class="menu-cask-offer"><a href="https://mh-distillery.com/cask/">CASK OFFER</a></li>
	<li class="menu-the-cocktails"><a href="https://mh-distillery.com/products-category/the-cocktails/">the cocktails</a></li>
</ul>
</li>
<li class="dropdown menu-visitor-center"><a class="dropdown-toggle" data-toggle="dropdown" data-target="#" href="https://mh-distillery.com/tours/">visitor center <b class="caret"></b></a>
<ul class="dropdown-menu">
	<li class="menu-private-tours"><a href="https://mh-distillery.com/tours/">Private Tours</a></li>
	<li class="menu-business-tours"><a href="https://mh-distillery.com/business-tours/">Business Tours</a></li>
</ul>
</li>
<li class="menu-who-we-are"><a href="https://mh-distillery.com/about/">who we are</a></li>
<li class="dropdown menu-find-us"><a class="dropdown-toggle" data-toggle="dropdown" data-target="#" href="https://mh-distillery.com/store-category/europe/">Find us <b class="caret"></b></a>
<ul class="dropdown-menu">
	<li class="menu-stores"><a href="https://mh-distillery.com/store-category/europe/">Stores</a></li>
	<li class="menu-bars-and-restaurants"><a href="https://mh-distillery.com/bar-category/israel/">Bars and restaurants</a></li>
</ul>
</li>
<li class="menu-press"><a href="https://mh-distillery.com/what-they-say-about-us/">PRESS</a></li>
<li class="menu-contact"><a href="https://mh-distillery.com/contact/">contact</a></li>
</ul>                    
<div class="lang_sel_list_horizontal wpml-ls-statics-shortcode_actions wpml-ls wpml-ls-legacy-list-horizontal" id="lang_sel_list">
	<ul><li class="icl-he wpml-ls-slot-shortcode_actions wpml-ls-item wpml-ls-item-he wpml-ls-first-item wpml-ls-item-legacy-list-horizontal">
				<a href="https://mh-distillery.com/he/" class="wpml-ls-link"><span class="wpml-ls-native icl_lang_sel_native">עבר</span></a>
			</li><li class="icl-en wpml-ls-slot-shortcode_actions wpml-ls-item wpml-ls-item-en wpml-ls-current-language wpml-ls-last-item wpml-ls-item-legacy-list-horizontal">
				<a href="https://mh-distillery.com" class="wpml-ls-link"><span class="wpml-ls-native icl_lang_sel_native">Eng</span></a>
			</li></ul>
</div>
                    <div class="clear-mobail clearfix"></div>
                    <ul class="right-menu">
                        <li>
                                                            <a class="facebook" href="https://www.facebook.com/MilkHoneyDistillery/" target="_blank" >
                                    <img src="https://mh-distillery.com/wp-content/themes/anova/assets/images/facebook.png">
                                </a>
                                                    </li>
                           <li>
                            <a class="instagram" href="https://www.instagram.com/milkandhoney_distillery/" target="_blank">
                                <img src="https://mh-distillery.com/wp-content/themes/anova/assets/images/instagram.png">
                            </a>
                        </li>
                         <li>
                            <a class="tripadvisor" href="https://www.tripadvisor.com/Attraction_Review-g293984-d10513571-Reviews-The_Milk_Honey_Distillery-Tel_Aviv_Tel_Aviv_District.html" target="_blank">
                                <img src="https://mh-distillery.com/wp-content/themes/anova/assets/images/trip-advisor-icon.png">
                            </a>
                        </li>
                        <li>
                            <a class="twitter" target="_blank" href="https://twitter.com/milkhoneywhisky" style="display: none;">
                                <img src="https://mh-distillery.com/wp-content/themes/anova/assets/images/twitter.png">
                            </a>
                        </li>
                        <li>
                            <a class="youtube" href="https://www.youtube.com/user/MHDistillery" target="_blank" style="display: none;">
                                <img src="https://mh-distillery.com/wp-content/themes/anova/assets/images/youtube.png">
                            </a>
                        </li>
                     </ul>
                    <ul id="menu-cart" class="nav navbar-nav"><li class="wpmenucartli wpmenucart-display-standard" id="wpmenucartli"><a class="wpmenucart-contents empty-wpmenucart" style="display:none">&nbsp;</a></li></ul>                </nav>
            </div>
        </div>
        <span class="searchFormBtn"></span>
        <!--div class="search pull-right"><//?php get_search_form();?>  </div-->
        </div>
    </div>
    <div class="clearfix"></div>
</header>
<script>
    jQuery(document).ready(function() {
        var $ = jQuery;
        $('a.tripadvisor').hover(() => {
            $('a.tripadvisor img').attr('src', 'https://mh-distillery.com/wp-content/themes/anova/assets/images/trip-advisor-yellow-icon.png');
        }, () => {
            $('a.tripadvisor img').attr('src', 'https://mh-distillery.com/wp-content/themes/anova/assets/images/trip-advisor-icon.png');
        });

        /*var element = $('.menu .nav li:last-child').detach();
        element.find('a').css('color', '#fdb813');
        element.css('display', 'inline');
        element.find('a').css('text-decoration', 'underline');
        element.find('a').css('font-size', '14px');
        $('div.lang_sel_list_horizontal ul').append(element);*/

    });

</script>
    <div class="main col-sm-12" role="main">
        <div class="homepage">
    <div class="max-container"></div>
        <div class="slider homeslider clearfix" dir="ltr" >
                                            <div class="slideWrap">
                                    <a href="https://mh-distillery.com/our-spirits/">
                                <div class="topSlide">
                                            <img src="https://mh-distillery.com/wp-content/uploads/2019/08/MH_Main_Slider_Products-_31_7_D.jpg" alt="sliderImage" class="desktop" />
                                                                <img src="https://mh-distillery.com/wp-content/uploads/2019/08/MH_Main_Slider_Products-_mobile_31_7_C_eng.jpg" alt="sliderImage" class=" desktop-tablet" />
                                                        </div>
<!--                <div class="bottomSlide">-->
<!--                    <div class="max-container image">-->
<!--                        <img src="--><!--"/>-->
<!--                    </div>-->
<!--                </div>-->
                                    </a>
                            </div>
                                            <div class="slideWrap">
                                    <a href="http://mh-distillery.com/visit-our-distillery/">
                                <div class="topSlide">
                                            <img src="https://mh-distillery.com/wp-content/uploads/2016/03/MH_Main_Slider_visit.jpg" alt="sliderImage" class="desktop" />
                                                                <img src="https://mh-distillery.com/wp-content/uploads/2016/03/MH_mobile_Slider_visit.jpg" alt="sliderImage" class=" desktop-tablet" />
                                                        </div>
<!--                <div class="bottomSlide">-->
<!--                    <div class="max-container image">-->
<!--                        <img src="--><!--"/>-->
<!--                    </div>-->
<!--                </div>-->
                                    </a>
                            </div>
                                            <div class="slideWrap">
                                    <a href="https://mh-distillery.com/our-spirits/">
                                <div class="topSlide">
                                            <img src="https://mh-distillery.com/wp-content/uploads/2018/11/MH_Main_Slider_Products-_5-11-2018.jpg" alt="sliderImage" class="desktop" />
                                                                <img src="https://mh-distillery.com/wp-content/uploads/2018/11/MH_Main_Slider_Products-_mobile_5-11-2018-1.jpg" alt="sliderImage" class=" desktop-tablet" />
                                                        </div>
<!--                <div class="bottomSlide">-->
<!--                    <div class="max-container image">-->
<!--                        <img src="--><!--"/>-->
<!--                    </div>-->
<!--                </div>-->
                                    </a>
                            </div>
                                            <div class="slideWrap">
                                    <a href="http://mh-distillery.com/cask/">
                                <div class="topSlide">
                                            <img src="https://mh-distillery.com/wp-content/uploads/2018/08/MH_Banner_Eng-1.jpg" alt="sliderImage" class="desktop" />
                                                                <img src="https://mh-distillery.com/wp-content/uploads/2016/03/MH_Banner_M_En.jpg" alt="sliderImage" class=" desktop-tablet" />
                                                        </div>
<!--                <div class="bottomSlide">-->
<!--                    <div class="max-container image">-->
<!--                        <img src="--><!--"/>-->
<!--                    </div>-->
<!--                </div>-->
                                    </a>
                            </div>
                                            <div class="slideWrap">
                                    <a href="https://mh-distillery.com/store-category/europe/">
                                <div class="topSlide">
                                            <img src="https://mh-distillery.com/wp-content/uploads/2018/10/MH_storelocator_banner_23-10-2.jpg" alt="sliderImage" class="desktop" />
                                                                <img src="https://mh-distillery.com/wp-content/uploads/2018/10/MH_Banner_Mobile_wwproducts.jpg" alt="sliderImage" class=" desktop-tablet" />
                                                        </div>
<!--                <div class="bottomSlide">-->
<!--                    <div class="max-container image">-->
<!--                        <img src="--><!--"/>-->
<!--                    </div>-->
<!--                </div>-->
                                    </a>
                            </div>
                                            <div class="slideWrap">
                                    <a href="https://mh-distillery.com/products-category/the-cocktails/">
                                <div class="topSlide">
                                            <img src="https://mh-distillery.com/wp-content/uploads/2018/10/MH_Main_Slider_cocktails-_2018.jpg" alt="sliderImage" class="desktop" />
                                                                <img src="https://mh-distillery.com/wp-content/uploads/2018/10/MH_Banner_Mobile_cocktails_.jpg" alt="sliderImage" class=" desktop-tablet" />
                                                        </div>
<!--                <div class="bottomSlide">-->
<!--                    <div class="max-container image">-->
<!--                        <img src="--><!--"/>-->
<!--                    </div>-->
<!--                </div>-->
                                    </a>
                            </div>
            </div>
        <div class="block the-spirit">
        <h2 class="title-block"><p><sup>OUR </sup>SPIRIT</p>
</h2>
                            <img src="https://mh-distillery.com/wp-content/uploads/2016/03/Our-spirits-New-bottle-s.jpg" class="desktop" />
                            <img src="https://mh-distillery.com/wp-content/uploads/2016/03/Our-spirits-mobile-eng.jpg" class=" desktop-tablet" />
                        <a class="view-products" href="https://mh-distillery.com/products-category/our-spirits/">VIEW OUR PRODUCTS</a>
    </div>
    <div class="block">
            <div class="about-homepage">
                                                    <img src="https://mh-distillery.com/wp-content/uploads/2016/03/home-who.jpg"  class="desktop" />
                                                    <img src="https://mh-distillery.com/wp-content/uploads/2016/03/MH_Home_M_who.jpg" class=" tablet" />
                                                    <img src="https://mh-distillery.com/wp-content/uploads/2016/03/MH_Home_M_480_who-1.jpg" class="mobile" />
                    <!--        <div class="background-image" style="background: url() no-repeat center center;">-->
            <div class="text-about-homepage">
                <h2 class="title-block"><p><sup>WHO</sup> WE ARE</p>
</h2>
                <h5>The Milk &amp; Honey is Israel’s first whisky distillery, creating top grade spirits with an ultimate goal to make local single malt whisky. </h5>
                <p>We take great care to ensure that what we make is an honest product. We neither compromise, nor take shortcuts. We use high quality barley, custom-made whisky stills and expertly selected casks. Whether it’s our single malt whisky or other premium spirits, we take pride in what we do and what we make. </p>
                <a class="buttob-white" href="https://mh-distillery.com/about/">MORE</a>
            </div>
        </div>
    </div>
    <div class="block made-in-tel-aviv">
        <h2 class="title-block"><p>MADE <sup>IN</sup> TEL AVIV</p>
</h2>
                    <img src="https://mh-distillery.com/wp-content/uploads/2016/03/icon.png"/>
                <p class="text">The first Israeli whisky distillery is located in the first city of Israel. Symbolic? Maybe, but it wasn’t for historic reasons that we chose to set the distillery here: Tel Aviv is the heart of Israel’s culinary and drinking scene. There are amazing indoor and outdoor markets here, world-class bars, and restaurants like no other place in the world. We are excited to be a part of the city that never stops. <br />
<br />
</p>
                    <img src="https://mh-distillery.com/wp-content/uploads/2016/03/MH_TelAviv_Home.jpg"/>
            </div>
    <div class="block">
        <div class="distilerry">
            <div class="max-container inner-distilerry">
                <div class="wrap-inner-distilerry">
                    <div class="left-distilerry">
                        <h2 class="title-block"><p>VISIT <sup>OUR</sup> DISTILLERY</p>
</h2>
                        <h5>Come visit us – a working distillery right in Tel Aviv, one-of-its-kind place in the whole country (and dare we say – in the Middle East?) and join us in our process. </h5>
                        <p>In our one hour tour, you will learn about the history and process of distillation, walk through the various stages of spirit making – from grain to glass – and finish with a guided tasting of our creations. <br />
Our distillery shop offers bottles, including special limited edition, exclusively available there, as well as unique gifts for whisky lovers and fans. <br />
We welcome individuals and groups, and are available for booking of private parties, groups and events. Advanced booking is required; go to our Visitor Center page for more details. </p>
                    </div>
                    <div class="right-distilerry">
                        <p><h4><strong>Advance booking required.</strong></h4>
<p><strong>Opening hours:</strong></p>
<table style="height: 184px;" width="282">
<tbody>
<tr>
<td><strong>SUN &#8211; THURS</strong></td>
<td style="text-align: right;">10:00 &#8211; 18:00</td>
</tr>
<tr>
<td><strong>FRIDAY</strong></td>
<td style="text-align: right;">9:00 &#8211; 14:00</td>
</tr>
<tr>
<td>&nbsp;</td>
<td style="text-align: right;"> </td>
</tr>
<tr>
<td><strong>Address</strong></td>
<td style="text-align: right;"> 16   HaThiya St.</td>
</tr>
<tr>
<td>&nbsp;</td>
<td style="text-align: right;"> Tel Aviv-Yafo Israel</td>
</tr>
<tr>
<td> <strong>Tel</strong></td>
<td style="text-align: right;"><a href="tel:97236320491"> +972-3-6320491</a></td>
</tr>
</tbody>
</table>
<h4> </h4>
</p>
                        <a class="buttob-yellow" href="https://mh-distillery.com/?page_id=106">MORE INFO</a>
                    </div>
                </div>
            </div>
                                        <img src="https://mh-distillery.com/wp-content/uploads/2016/03/MH_Distilley_Home.jpg" class="desktop" />
                                        <img src="https://mh-distillery.com/wp-content/uploads/2016/03/MH_Home_M_visit-999.jpg" class=" tablet" />
                                        <img src="https://mh-distillery.com/wp-content/uploads/2016/03/MH_Home_M_480_visit-1.jpg" class="mobile" />
                    </div>
    </div>
    <div class="block prodact-homepage">
        <div class="container cocktails">
            <h2 class="title-block"><p><sup>OUR </sup>COCKTAILS</p>
</h2>
            <div class="clearfix" >
                                    <div class="inner-slider-cock row">
                        <div class="slider slider-products-homepage left col-sm-7 col-xs-12" dir="ltr">
                                                                            <div class="wrap">
                                    <div class="image-cocktail">
                                                                                    <img src="https://mh-distillery.com/wp-content/uploads/2016/03/MH_Cocktail_01_SQ_web.jpg" />
                                                                            </div>
                                </div>

                                                                                                    <div class="wrap">
                                    <div class="image-cocktail">
                                                                                    <img src="https://mh-distillery.com/wp-content/uploads/2016/04/MH_Cocktail_04_SQ_web.jpg" />
                                                                            </div>
                                </div>

                                                                                                    <div class="wrap">
                                    <div class="image-cocktail">
                                                                                    <img src="https://mh-distillery.com/wp-content/uploads/2016/05/Silver-screen.jpg" />
                                                                            </div>
                                </div>

                                                                                                    <div class="wrap">
                                    <div class="image-cocktail">
                                                                                    <img src="https://mh-distillery.com/wp-content/uploads/2016/05/MH_Cocktail_06_CU_SQ_web.jpg" />
                                                                            </div>
                                </div>

                                                                                                    <div class="wrap">
                                    <div class="image-cocktail">
                                                                                    <img src="https://mh-distillery.com/wp-content/uploads/2016/05/MH_Cocktail_05_CU_SQ_web.jpg" />
                                                                            </div>
                                </div>

                                                                    </div>
                        <div class="right slider-products-text-homepage col-sm-5 col-xs-12" dir="ltr">
                                                                                    <div class="inner">
                                <h2>SERGEANT PEPPER</h2>
                                                                    <img src="https://mh-distillery.com/wp-content/uploads/2016/03/icon-1-1.png" />
                                                                            <p class="bold">Green pepper gives a fresh twist to this aromatic sweet and sour cocktail. </p class="bold">
                                                                                                    </div>
                                                                                    <div class="inner">
                                <h2>Negroniño</h2>
                                                                <img src="https://mh-distillery.com/wp-content/themes/anova/assets/images/icon-cock.png"/>
                                                                            <p class="bold">A refreshing variation of a timeless classic. The combination of the light and bitter Aperol and the higher proof New Make creates a refreshing and balanced cocktail.<br />
</p class="bold">
                                                                                                    </div>
                                                                                    <div class="inner">
                                <h2>Silver Screen</h2>
                                                                <img src="https://mh-distillery.com/wp-content/themes/anova/assets/images/icon-cock.png"/>
                                                                            <p class="bold">While this cocktail seems quite advanced, once you have the ingredients handy, it’s a quick one to make. Make sure to use freshly squeezed lemon juice.<br />
</p class="bold">
                                                                                                    </div>
                                                                                    <div class="inner">
                                <h2>Heard It Trough The Grapevine</h2>
                                                                <img src="https://mh-distillery.com/wp-content/themes/anova/assets/images/icon-cock.png"/>
                                                                            <p class="bold">Grapes, lime and agave – can it get more summery than this? This is a light and refreshing expression of a New Make-based cocktail. Ideal for a rooftop gathering on a Friday afternoon. </p class="bold">
                                                                                                    </div>
                                                                                    <div class="inner">
                                <h2>Not-So-Rusty Nail</h2>
                                                                <img src="https://mh-distillery.com/wp-content/themes/anova/assets/images/icon-cock.png"/>
                                                                            <p class="bold">A heart – and gut – warming cocktail, for  slow after-dinner sipping or a winter comfort.</p class="bold">
                                                                                                    </div>
                                                </div>
                    </div>
                            </div>
                            <a class="buttob-yellow" href="https://mh-distillery.com/products-category/the-cocktails/">VIEW MORE</a>
                    </div>
    </div>
            <div class="block">
            <div class="newsletter">
                <div class="container" style="display: none;">
                  <h3>SIGN UP FOR OUR NEWSLETTER</h3>
                    <div role="form" class="wpcf7" id="wpcf7-f1584-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"></div>
<form action="/index.php#wpcf7-f1584-o1" method="post" class="wpcf7-form" novalidate="novalidate">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="1584" />
<input type="hidden" name="_wpcf7_version" value="5.0.3" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f1584-o1" />
<input type="hidden" name="_wpcf7_container_post" value="0" />
</div>
<p><span class="wpcf7-form-control-wrap title"><input type="hidden" name="title" value="newsletter" size="40" class="wpcf7-form-control wpcf7dtx-dynamictext wpcf7-dynamichidden" aria-invalid="false" /></span><span class="wpcf7-form-control-wrap email"><input type="email" name="email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="YOUR EMAIL" /></span>
<div class="wpcf7-form-control-wrap"><div data-sitekey="6LfCopYUAAAAAN1UxOE14qeT-uzqCI1OlhhQgfV_" class="wpcf7-form-control g-recaptcha wpcf7-recaptcha"></div>
<noscript>
	<div style="width: 302px; height: 422px;">
		<div style="width: 302px; height: 422px; position: relative;">
			<div style="width: 302px; height: 422px; position: absolute;">
				<iframe src="https://www.google.com/recaptcha/api/fallback?k=6LfCopYUAAAAAN1UxOE14qeT-uzqCI1OlhhQgfV_" frameborder="0" scrolling="no" style="width: 302px; height:422px; border-style: none;">
				</iframe>
			</div>
			<div style="width: 300px; height: 60px; border-style: none; bottom: 12px; left: 25px; margin: 0px; padding: 0px; right: 25px; background: #f9f9f9; border: 1px solid #c1c1c1; border-radius: 3px;">
				<textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid #c1c1c1; margin: 10px 25px; padding: 0px; resize: none;">
				</textarea>
			</div>
		</div>
	</div>
</noscript>
</div>
<p><input type="submit" value="REGISTER" class="wpcf7-form-control wpcf7-submit" /></p>
<div class="wpcf7-response-output wpcf7-display-none"></div></form></div><!--                    <form id="form-newsletter" method="post" action="">-->
<!--                        <input type="hidden" name="title" value="newsletter"/>-->
<!--                        <input placeholder="--><!--" type="mail" name="email" />-->
<!--                        <input placeholder="--><!--" type="mail" name="email" />-->
<!---->
<!--                        <input type="hidden" name="uid" value="B92PK8KH35ST03RYOKA2"/>-->
<!--                        <input type="hidden" name="ajax" value="true"/>-->
<!--                        <input type="hidden" name="test" value="true"/>-->
<!---->
<!--                        <input class="submit" type="submit" name="submit" id="submit" value="--><!--"/>-->
<!--                    </form>-->
                    <div class="clearfix"></div>
                </div>
                <div class="container" id="mc4wp_form">
                    <script>(function() {
	if (!window.mc4wp) {
		window.mc4wp = {
			listeners: [],
			forms    : {
				on: function (event, callback) {
					window.mc4wp.listeners.push({
						event   : event,
						callback: callback
					});
				}
			}
		}
	}
})();
</script><!-- MailChimp for WordPress v4.2.4 - https://wordpress.org/plugins/mailchimp-for-wp/ --><form id="mc4wp-form-1" class="mc4wp-form mc4wp-form-3461 mc4wp-ajax" method="post" data-id="3461" data-name="main page - English" ><div class="mc4wp-form-fields"><p>
	<label>SIGN UP FOR OUR NEWSLETTER </label>
	<input type="email" name="EMAIL" placeholder="YOUR EMAIL" required />
  <input type="submit" value="REGISTER" />
</p></div><label style="display: none !important;">Leave this field empty if you're human: <input type="text" name="_mc4wp_honeypot" value="" tabindex="-1" autocomplete="off" /></label><input type="hidden" name="_mc4wp_timestamp" value="1568210120" /><input type="hidden" name="_mc4wp_form_id" value="3461" /><input type="hidden" name="_mc4wp_form_element_id" value="mc4wp-form-1" /><div class="mc4wp-response"></div></form><!-- / MailChimp for WordPress Plugin -->                </div>
            </div>
        </div>
        <div class="block" style="display: none !important;">
        <div class="bar-locator">
            <h2 class="title-block"><p>TRY <sup>our</sup> products</p>
</h2>
                        <img src="https://mh-distillery.com/wp-content/uploads/2016/03/bar-locator.png"/>
                        </div>
    </div>
    <div class="block contact-us">
        <h2 class="title-block"><p>CONTACT <sup>US</sup></p>
</h2>
        <div class="center">
            <div class="contact">
                <p>FOR SALES, B2B AND DISTRIBUTION</p>
                <a href="https://mh-distillery.com/contact/">CONTACT</a>
            </div>
            <div class="contact">
                <p>FOR GENERAL INQUIRIES AND VISITOR CENTER</p>

                <a href="https://mh-distillery.com/contact/">CONTACT</a>
            </div>
        </div>
    </div>
    <div class="block">
        <div class="thank_you">
            <div class="max-container">
                <h2>THANK YOU</h2>
                <p>Special thanks for all our early supporters on Indiegogo</p>
                <a href="https://mh-distillery.com/supporter/">SUPPORTER'S PAGE</a>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
    </div><!-- /.main -->

<a href="#" id="up"></a>

<footer class="content-info" role="contentinfo">
  <div class="block">
    <div class="container">
            <div class="inner-footer row">
        <div class="left col-sm-4 col-xs-3">
          <img src="https://mh-distillery.com/wp-content/uploads/2016/04/icon-MH.png" />
        </div>
        <div class="center-d col-sm-4 col-xs-6">
          <h3>PLEASE DRINK RESPONSIBLY</h3>
          <p>©2016  The Milk & Honey distillery. Tel Aviv Israel</p>
        </div>
        <div class="right col-sm-4 col-xs-3">
          <p>privacy policy</p>
        </div>
      </div>
<!--      <div class="wrap-wight">-->
<!--        --><!--      </div>-->
    </div>
    <div class="clearfix"></div>
  </div>
  <div class="credite">
    <div class="container">
      <div class="left">
        <div class="credit"> <a href="http://www.planb.design" rel="nofollow" target="_blank">Design - Plan b creative team</a></div>
      </div>
      <div class="right">
        <!--<div class="credit"> <a href="http://www.anova.co.il" rel="nofollow" target="_blank">development - <span>a</span>nova web development</a></div>!-->
         <div class="credit"> <a href="https://getraffic.co.il/" rel="nofollow" target="_blank">eCommerce Development: Get Traffic</a></div>
      </div>
    </div>
  </div>
</footer>
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<script type="text/javascript" src="https://mh-distillery.com/wp-content/themes/anova/assets/js/slick.js"></script>
<script type="text/javascript" src="https://mh-distillery.com/wp-content/themes/anova/assets/js/jquery.validate.min.js"></script>
<!-- Start of Nagishly Pixel script (Copy and paste this to your website) -->

<script>(function(document, tag) { var script = document.createElement(tag); var element = document.getElementsByTagName('body')[0]; script.src = 'https://accessibeapp.com/api/v1/assets/js/accessibe.js'; script.async = true; script.defer = true; (typeof element === 'undefined' ? document.getElementsByTagName('html')[0] : element).appendChild(script); script.onload = function() { AccessiBe.init({ clientId : 179, clientKey : 'jW9JLGpYU0qVXjHsum1Q', wlbl : 'Nagishly', statementLink : '', feedbackLink : '', showAllActions : false, keyNavStrong : false, hideMobile : false, hideTrigger : false, language : 'he', focusInnerColor : '#146FF8', focusOuterColor : '#ff7216', leadColor : '#146FF8', triggerColor : '#146FF8', size : 'big', position : 'left', triggerRadius : '50%', triggerPositionX : 'left', triggerPositionY : 'bottom', triggerIcon : 'default', triggerSize : 'medium', triggerOffsetX : 20, triggerOffsetY : 20, usefulLinks : { }, mobile : { triggerSize : 'small', triggerPositionX : 'right', triggerPositionY : 'bottom', triggerOffsetX : 0, triggerOffsetY : 0, triggerRadius : '0' } }); };}(document, 'script'));</script>

<!-- End of Nagishly Pixel script --><script type="text/javascript">
var recaptchaWidgets = [];
var recaptchaCallback = function() {
	var forms = document.getElementsByTagName( 'form' );
	var pattern = /(^|\s)g-recaptcha(\s|$)/;

	for ( var i = 0; i < forms.length; i++ ) {
		var divs = forms[ i ].getElementsByTagName( 'div' );

		for ( var j = 0; j < divs.length; j++ ) {
			var sitekey = divs[ j ].getAttribute( 'data-sitekey' );

			if ( divs[ j ].className && divs[ j ].className.match( pattern ) && sitekey ) {
				var params = {
					'sitekey': sitekey,
					'type': divs[ j ].getAttribute( 'data-type' ),
					'size': divs[ j ].getAttribute( 'data-size' ),
					'theme': divs[ j ].getAttribute( 'data-theme' ),
					'badge': divs[ j ].getAttribute( 'data-badge' ),
					'tabindex': divs[ j ].getAttribute( 'data-tabindex' )
				};

				var callback = divs[ j ].getAttribute( 'data-callback' );

				if ( callback && 'function' == typeof window[ callback ] ) {
					params[ 'callback' ] = window[ callback ];
				}

				var expired_callback = divs[ j ].getAttribute( 'data-expired-callback' );

				if ( expired_callback && 'function' == typeof window[ expired_callback ] ) {
					params[ 'expired-callback' ] = window[ expired_callback ];
				}

				var widget_id = grecaptcha.render( divs[ j ], params );
				recaptchaWidgets.push( widget_id );
				break;
			}
		}
	}
};

document.addEventListener( 'wpcf7submit', function( event ) {
	switch ( event.detail.status ) {
		case 'spam':
		case 'mail_sent':
		case 'mail_failed':
			for ( var i = 0; i < recaptchaWidgets.length; i++ ) {
				grecaptcha.reset( recaptchaWidgets[ i ] );
			}
	}
}, false );
</script>
    <script type="text/javascript">
        document.addEventListener('wpcf7mailsent', function (event) {
            if ('1604' == event.detail.contactFormId || '1603' == event.detail.contactFormId) {
                anova_js_success_tracking();
            } else {
                anova_js_success();
            }
        }, false);
    </script>
    <script>(function() {function addEventListener(element,event,handler) {
	if(element.addEventListener) {
		element.addEventListener(event,handler, false);
	} else if(element.attachEvent){
		element.attachEvent('on'+event,handler);
	}
}function maybePrefixUrlField() {
	if(this.value.trim() !== '' && this.value.indexOf('http') !== 0) {
		this.value = "http://" + this.value;
	}
}

var urlFields = document.querySelectorAll('.mc4wp-form input[type="url"]');
if( urlFields && urlFields.length > 0 ) {
	for( var j=0; j < urlFields.length; j++ ) {
		addEventListener(urlFields[j],'blur',maybePrefixUrlField);
	}
}/* test if browser supports date fields */
var testInput = document.createElement('input');
testInput.setAttribute('type', 'date');
if( testInput.type !== 'date') {

	/* add placeholder & pattern to all date fields */
	var dateFields = document.querySelectorAll('.mc4wp-form input[type="date"]');
	for(var i=0; i<dateFields.length; i++) {
		if(!dateFields[i].placeholder) {
			dateFields[i].placeholder = 'YYYY-MM-DD';
		}
		if(!dateFields[i].pattern) {
			dateFields[i].pattern = '[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01])';
		}
	}
}

})();</script>	<script type="text/javascript">
		var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;
	</script>
	<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/mh-distillery.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}}};
/* ]]> */
</script>
<script type='text/javascript' src='/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.0.3'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var FUE_Front = {"is_logged_in":"","ajaxurl":"https:\/\/mh-distillery.com\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='/wp-content/plugins/woocommerce-follow-up-emails/templates/js/fue-front.js?ver=4.8.10'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/mh-distillery.com\/cart\/","is_cart":"","cart_redirect_after_add":"yes"};
/* ]]> */
</script>
<script type='text/javascript' src='/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=3.4.3'></script>
<script type='text/javascript' src='/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70'></script>
<script type='text/javascript' src='/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=3.4.3'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_040a68f470834c473560f8f6295259f7","fragment_name":"wc_fragments_040a68f470834c473560f8f6295259f7"};
/* ]]> */
</script>
<script type='text/javascript' src='/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=3.4.3'></script>
<script type='text/javascript' src='/wp-content/plugins/mc4wp-premium/ecommerce3/assets/js/tracker.min.js?ver=4.5.1'></script>
<script type='text/javascript' src='/wp-content/themes/roots/assets/js/scripts.min.js?ver=2a3e700c4c6e3d70a95b00241a845695'></script>
<script type='text/javascript' src='/wp-includes/js/wp-embed.min.js?ver=4.9.11'></script>
<script type='text/javascript' src='https://www.google.com/recaptcha/api.js?onload=recaptchaCallback&#038;render=explicit&#038;ver=2.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var mc4wp_forms_config = [];
/* ]]> */
</script>
<script type='text/javascript' src='/wp-content/plugins/mailchimp-for-wp/assets/js/forms-api.min.js?ver=4.2.4'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var mc4wp_ajax_vars = {"loading_character":"\u2022","ajax_url":"https:\/\/mh-distillery.com\/wp-admin\/admin-ajax.php?action=mc4wp-form","error_text":"Oops. Something went wrong. Please try again later."};
/* ]]> */
</script>
<script type='text/javascript' src='/wp-content/plugins/mc4wp-premium/ajax-forms/assets/js/ajax-forms.min.js?ver=4.5.1'></script>
<!--[if lte IE 9]>
<script type='text/javascript' src='/wp-content/plugins/mailchimp-for-wp/assets/js/third-party/placeholders.min.js?ver=4.2.4'></script>
<![endif]-->
<!-- WooCommerce JavaScript -->
<script type="text/javascript">
jQuery(function($) { 

					$( '.add_to_cart_button:not(.product_type_variable, .product_type_grouped)' ).click( function() {
						ga( 'ec:addProduct', {'id': ($(this).data('product_sku')) ? ($(this).data('product_sku')) : ('#' + $(this).data('product_id')),'quantity': $(this).data('quantity')} );
						ga( 'ec:setAction', 'add' );
						ga( 'send', 'event', 'UX', 'click', 'add to cart' );
					});
				

ga( 'send', 'pageview' ); 
 });
</script>



<script type="text/javascript" src="https://mh-distillery.com/wp-content/themes/anova/assets/js/anova.js"></script>
<script type="text/javascript">
    var ajax_url = 'https://mh-distillery.com/wp-admin/admin-ajax.php';
</script>

</body>
</html>
